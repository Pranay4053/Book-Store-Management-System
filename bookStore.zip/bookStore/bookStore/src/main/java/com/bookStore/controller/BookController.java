package com.bookStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.bookStore.entity.Book;
import com.bookStore.service.BookService;

@Controller
public class BookController {
	
	@Autowired
	private BookService bService;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping("/book_register")
	public String bookRegister()
	{
		return "bookRegister";
	}
	
	@GetMapping("/available_books")
	public ModelAndView getallBooks()
	{
		List<Book> list = bService.getallBooks();
		//ModelAndView mv= new ModelAndView();
		//mv.setViewName("bookList");
		
		return new ModelAndView("bookList", "book",list);
	}
	
	@PostMapping("/save")
	public String addBook(@ModelAttribute Book b) {
		
		bService.save(b);
		return "redirect:/available_books";
		
		
	}
		
	

}
